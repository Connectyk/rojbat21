(function () {
  var burger = document.querySelector('.burger');
  var nav = document.getElementById('menu');
  if (burger && nav) {
    burger.addEventListener('click', function () {
      var ouvert = nav.classList.toggle('ouvert');
      burger.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
      burger.textContent = ouvert ? 'Fermer' : 'Menu';
    });
  }

  var form = document.querySelector('form.devis');
  if (!form) return;
  var TEL_WA = form.getAttribute('data-wa');
  var EMAIL = form.getAttribute('data-email');

  function message() {
    var d = new FormData(form);
    var lignes = [
      'Bonjour, je souhaite un devis.',
      'Nom : ' + (d.get('nom') || ''),
      'Téléphone : ' + (d.get('telephone') || ''),
      'Commune du chantier : ' + (d.get('commune') || ''),
      'Type de travaux : ' + (d.get('travaux') || ''),
      '',
      (d.get('message') || '')
    ];
    return lignes.join('\n').trim();
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!form.reportValidity()) return;
    var canal = e.submitter && e.submitter.value === 'email' ? 'email' : 'whatsapp';
    var texte = message();
    if (canal === 'email') {
      window.location.href = 'mailto:' + EMAIL + '?subject=' + encodeURIComponent('Demande de devis') + '&body=' + encodeURIComponent(texte);
    } else {
      window.open('https://wa.me/' + TEL_WA + '?text=' + encodeURIComponent(texte), '_blank', 'noopener');
    }
  });
})();
